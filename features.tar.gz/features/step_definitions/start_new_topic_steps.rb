Given /^I am a participant in a Konversation$/ do |arg|
  pending
end
#Test and place in paths
When /^I fill in "(.+)" with "(.+)"$/ do |arg|
  @heading = arg[1].split(/\s/).join('_')
  fill_in @heading, with: arg[2]
end

When /^I press Enter$/ do
  find_field(@heading).native.send_key(:enter)
end

Then /^I should see a new topic page$/ do
  page.should have_content @topic
end

When /^I enter email addresses or Sidibat Ids of others$/ do
pending
end

When /^I select the profile 'test'$/ do
  pending # express the regexp above with the code you wish you had
end

When /^click on 'post'$/ do
  pending # express the regexp above with the code you wish you had
end

When /^select mood 'green'$/ do
  pending # express the regexp above with the code you wish you had
end


