
When /^I hover the mouse over "([^"]*)"$/ do |arg1|
pending "selenium does not seem to work with hover, need to explore Culerity"
  fireEvent(arg1,"hover")
end

Then /^I should see information on the topic$/ do
puts "Need client input on what the content should be"
pending
  page.should have_content("This information has to be added as per design requirements")
end

