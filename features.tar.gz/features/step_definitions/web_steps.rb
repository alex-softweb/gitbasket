When /^(?:|I )go to the (.+)$/ do |page|
  visit path_to(page)
end

Given /^(?:|I )am on the (.+)$/ do |page|
  visit path_to(page)
end

Then /^(?:|I )should be on the (.+)$/i do |page| 
  visit path_to(page)  
end

Then /^I should see a new "(.+)" page$/ do |controller|
  url = controller.concat("s/new") 
  current_path.should match url
end

