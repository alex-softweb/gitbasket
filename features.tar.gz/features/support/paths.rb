#When /conversation main page/ do
#  conversations_path
#end

def path_to(page_name)

  case page_name  
  when /home page/    
       visit login_path
  when /new conversation page/
       visit new_conversation_path  
  when /Konversation's main page/
      visit conversation_path(1)
  when /new topic page/i
    page.should have_content "Start a New Topic"
  when /complete profile page/ 
    current_path.should match 'complete_profile'
  when /getting started page/
puts "***add the getting started path to conversations***"
pending
    visit getting_started_page
  end

end
