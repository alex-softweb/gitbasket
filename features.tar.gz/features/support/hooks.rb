Before do
  @tester = Factory(:user)
end

