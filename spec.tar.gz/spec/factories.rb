Factory.define(:user) do |u|
  u.first_name 'alex'
  u.last_name 'john'
  u.email 'alex@alex.com'
  u.password "2b4e6b2e2631305ce31bf8805fcf8c1432685074aed93cc51a1..." 
end
