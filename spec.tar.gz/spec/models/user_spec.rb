require 'active_record'
require 'spec_helper'

describe "What is going on?" do
  before(:each) do
    @user = Factory.create(:user)
  end



  it "Should validate" do
      puts @user.first_name
  end
end
